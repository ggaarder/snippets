#include <stdio.h>

int main(void)
{
	char s[30000];
	FILE *f = fopen("x.txt", "r");
	
	fread(s, sizeof(s), 1, f);
	puts(s);

	return 0;
}